Place slider images here so Vite serves them as static assets.

Expected files for BlockchainTrazabilidad slider:
- image1.png
- image2.png
- image3.png

They will be available at:
- /assets/images/image1.png
- /assets/images/image2.png
- /assets/images/image3.png
